/////////////////////////////////////////////////////////////////////
// Use this class to insert into middlewares into the pipeline
// 
/////////////////////////////////////////////////////////////////////
// Author : Nicolas Chourot
// Lionel-Groulx College
/////////////////////////////////////////////////////////////////////

// Importer le cache manager.
const CachedRequestsManager = require('./CachedRequestsManager');

// Démarrer le nettoyage périodique du cache au lancement du serveur.
CachedRequestsManager.startCachedRequestsCleaner();

export default class MiddlewaresPipeline {
    constructor() {
        this.middlewares = [];
    }

    // Ajouter un middleware dans le pipeline.
    add(middleware) {
        this.middlewares.push(middleware);
    }

    // Gérer la requête via la chaîne des middlewares.
    async handleHttpRequest(HttpContext) {
        for (let middleware of this.middlewares) {
            if (await middleware(HttpContext)) return true; // Stop si un middleware a géré la requête
        }
        return false; // Continuer si aucun middleware n'a géré la requête
    }
}

// Créer une instance du pipeline de middlewares.
const middlewaresPipeline = new MiddlewaresPipeline();

// Ajouter le middleware de cache au pipeline.
middlewaresPipeline.add(async (HttpContext) => {
    return CachedRequestsManager.get(HttpContext); // Utiliser le cache si possible
});

// Exporter le pipeline pour l'utiliser dans le reste de l'application.
module.exports = middlewaresPipeline;