/////////////////////////////////////////////////////////////////////
// This module defines the HttpContext class.
// When the server receives an HTTP request, an instance of 
// HttpContext is created, holding all the information of the
// request, including the payload if the verb is GET or PUT.
/////////////////////////////////////////////////////////////////////
// Author: Nicolas Chourot
// Lionel-Groulx College
/////////////////////////////////////////////////////////////////////
import queryString from "query-string";
import Response from "./response.js";
import * as utilities from "./utilities.js";
import CachedRequestsManager from "./CachedRequestsManager.js"; // Import the cache manager.

let httpContext = null;

export default class HttpContext {
    constructor(req, res) {
        this.req = req;
        this.res = res;
        this.path = utilities.decomposePath(req.url);
        this.response = new Response(this); // Assign the response object.
        this.payload = null;
        this.secure = req.headers['x-forwarded-proto'] != undefined;
        this.host = (this.secure ? "https://" : "http://") + req.headers["host"];
        this.hostIp = req.headers['x-forwarded-for'] != undefined 
            ? req.headers['x-forwarded-for'].substring(0, 15) 
            : (req.connection.remoteAddress == "::1" ? "localhost" : req.connection.remoteAddress.substring(0, 15));
        this.isCacheable = this.path.isAPI && this.req.method == "GET" && this.path.id == undefined;

        // Extend the response object with the JSON method.
        this.response.JSON = (jsonObj, ETag = "", fromCache = false) => {
            const { url } = this.req;

            // Add response to the cache if not from cache and the request is cacheable.
            if (!fromCache && this.isCacheable) {
                CachedRequestsManager.add(url, jsonObj, ETag);
                console.log(`Cache added for URL: ${url}`);
            }

            // Set the ETag header and send the response.
            this.res.setHeader("ETag", ETag);
            this.res.status(200).json(jsonObj);
        };
    }

    static get() {
        return httpContext;
    }

    async getJSONPayload() {
        return await new Promise(resolve => {
            let body = [];
            this.req.on('data', chunk => {
                body += chunk; // body.push(chunk) was a mistake and does not work with large data.
            }).on('end', () => {
                if (body.length > 0) {
                    if (this.req.headers['content-type'] == "application/json") {
                        try {
                            this.payload = JSON.parse(body);
                        } catch (error) {
                            console.log(`[${error}]`);
                            this.payload = null;
                        }
                    } else if (this.req.headers["content-type"] === "application/x-www-form-urlencoded") {
                        try {
                            this.payload = queryString.parse(body.toString());
                        } catch (error) {
                            console.log(error);
                        }
                    }
                } else {
                    try {
                        this.payload = queryString.parse(utilities.getQueryString(this.req.url));
                    } catch (error) {
                        console.log(`[${error}]`);
                    }
                }
                if (this.payload != null && Object.keys(this.payload).length === 0) {
                    this.payload = null;
                }
                resolve(this.payload);
            });
        });
    }

    static async create(req, res) {
        httpContext = new HttpContext(req, res);
        await httpContext.getJSONPayload();
        return httpContext;
    }
}
