import * as utilities from "../utilities.js";

const cache = new Map(); // Utilisation de Map pour stocker les caches en mémoire
const CACHE_EXPIRATION_TIME = 600; // Expiration de 10 minutes en secondes

export default class CachedRequestsManager {
    
    static startCachedRequestsCleaner() {
        console.log("[Periodic cache cleaning process started...]");
        setInterval(CachedRequestsManager.flushExpired, CACHE_EXPIRATION_TIME * 1000);
    }

    static add(url, content, ETag = "") {
        const expireTime = utilities.nowInSeconds() + CACHE_EXPIRATION_TIME;
        cache.set(url, { content, ETag, expireTime });
        console.log(`[Added to cache: ${url}]`);
    }

    static find(url) {
        const cachedData = cache.get(url);
        if (cachedData) {
            cachedData.expireTime = utilities.nowInSeconds() + CACHE_EXPIRATION_TIME; // Renouvellement de la cache
            console.log(`[Retrieved from cache: ${url}]`);
            return cachedData;
        }
        return null;
    }

    static clear(url) {
        if (cache.has(url)) {
            cache.delete(url);
            console.log(`[Cleared cache for: ${url}]`);
        }
    }

    static flushExpired() {
        const now = utilities.nowInSeconds();
        for (const [url, data] of cache.entries()) {
            if (data.expireTime <= now) {
                console.log(`[Expired cache removed: ${url}]`);
                cache.delete(url);
            }
        }
    }

    static get(HttpContext) {
        const url = HttpContext.request.url;
        const cachedData = CachedRequestsManager.find(url);
        if (cachedData) {
            const { content, ETag } = cachedData;
            HttpContext.response.JSON(content, ETag, true); // Réponse avec cache
            return true; // Indiquer que la cache a été utilisée
        }
        return false;
    }
}
